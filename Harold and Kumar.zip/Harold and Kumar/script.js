// Example JavaScript to demonstrate interactivity

// Wait until the DOM is fully loaded
document.addEventListener("DOMContentLoaded", () => {
    const section1 = document.querySelector('#section1');
    
    // Add a button that changes text when clicked
    const button = document.createElement('button');
    button.innerText = 'Click me to change section 1 text!';
    
    button.addEventListener('click', () => {
        section1.querySelector('p').innerText = 'Section 1 text has been changed!';
    });
    
    section1.appendChild(button);
});
